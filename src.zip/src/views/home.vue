<template>
    <div class="app">
      <h2>Welcome to our TodoList Application!</h2>
      <p>Suzana Assefa  DEDEFA </p>
      <p> Miezan KABLAN </p>
      <p> Oussama  </p>
      <p> Emanuel </p> 
    </div>
</template>

<script>

</script>

<style src="../style/app.css"></style>
