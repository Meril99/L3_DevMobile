export default function () {
    return {
      token: localStorage.getItem('token') || null,
      filter: 'all',
      todos: [],
    }
}
